
Junior Data Analyst Assessment iHub

Section 1: Civic Technology – EGDI Analysis

## Objective:
Analyze secondary data from the UN's E-Government Development Index (EGDI) to draw insights on digital governance trends across countries.

# Key Tasks:
1. Identify and curate a credible civic technology dataset (EGDI).
2. Clean and analyze the data.
3. Visualize key trends.
4. Produce a professional report documenting insights.


## Section 2: Talent Survey Statistical Analysis

## Objective:
Perform exploratory and inferential statistical analysis on a survey dataset capturing student opinions on tech education and training.

# Key Tasks:
1. Generate descriptive statistics (e.g., demographics, satisfaction).
2. Identify most common programming languages.
3. Perform t-tests and chi-square tests.
4. Visualize results.
5. Ensure code is reproducible across environments.



## Section 3: NLP & Emerging Technology Analysis

## Objective:
Use Natural Language Processing (NLP) techniques to extract structured insights from unstructured text about biomedical innovations.

# Key Tasks:
1. Define and apply Named Entity Recognition (NER).
2. Extract organizations, locations, dates, and amounts.
3. Perform topic modeling (LDA).
4. Summarize using transformer models.
5. Classify texts into biomedical technology categories using unsupervised learning.
6. Detect and explain emerging trends.



##  Technologies Used

- Python
- Jupyter Notebooks
- pandas, numpy, matplotlib, seaborn
- scikit-learn, scipy, statsmodels
- spaCy, NLTK, gensim
- HuggingFace Transformers
- WordCloud, PyLDAvis





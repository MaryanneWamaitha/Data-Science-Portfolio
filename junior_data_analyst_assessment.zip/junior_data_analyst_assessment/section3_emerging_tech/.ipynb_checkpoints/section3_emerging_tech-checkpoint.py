### 1. Define Entity Recognition: 

Named Entity Recognition (NER) is an NLP task where entities such as people, organisations, locations, dates, and monetary amounts are identified and classified within text.

# Import necessary libraries 
import pandas as pd
import spacy
import matplotlib.pyplot as plt
from collections import Counter
from bertopic import BERTopic
from sklearn.feature_extraction.text import TfidfVectorizer
from transformers import pipeline
from sklearn.cluster import KMeans
from sklearn.preprocessing import normalize
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

# Load dataset
df = pd.read_csv("section3_emerging_tech/data/text_data.csv")
stories = df["story"].dropna().tolist()

# Step 1 & 2: Named Entity Recognition
nlp = spacy.load("en_core_web_sm")
entities_all = []

for story in stories:
    doc = nlp(story)
    entities_all.extend([ent.label_ for ent in doc.ents if ent.label_ in ["GPE", "ORG", "PERSON", "DATE", "MONEY"]])

entity_counts = Counter(entities_all)

# Plot NER counts
plt.figure(figsize=(8, 5))
plt.bar(entity_counts.keys(), entity_counts.values(), color='purple')
plt.title("Named Entity Frequencies")
plt.xlabel("Entity Type")
plt.ylabel("Count")
plt.grid(True)
plt.tight_layout()
#plt.savefig("section3_emerging_tech/entity_counts.png")
plt.show()

#Topic Modelling
topic_model = BERTopic(language="english")
topics, _ = topic_model.fit_transform(stories)

# Visualising the topics
topic_model.visualize_barchart(top_n_topics=10).show()

# Summarisation (Transformer)
summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6")
df["summary"] = df["story"].apply(lambda x: summarizer(x[:1000], max_length=130, min_length=30, do_sample=False)[0]["summary_text"])

# Unsupervised classification into categories
categories = [
    "Advanced Gene Editing", "mRNA Technology", "CAR-T Cell Therapy", "Organoids and Tissue Engineering",
    "Single-Cell Genomics", "Synthetic Biology", "Biological Computing", "Wearable Biosensors",
    "Microbiome Therapeutics", "Nanomedicine"
]

vectorizer = TfidfVectorizer(stop_words='english', max_features=1000)
X = vectorizer.fit_transform(stories)
X_norm = normalize(X)

# Use KMeans for clustering
k = len(categories)
kmeans = KMeans(n_clusters=k, random_state=42)
labels = kmeans.fit_predict(X_norm)

df["cluster_label"] = labels
category_map = {i: categories[i] for i in range(k)}
df["predicted_category"] = df["cluster_label"].map(category_map)

# Count category distribution
category_distribution = df["predicted_category"].value_counts(normalize=True) * 100
category_distribution.plot(kind='bar', title="Story Classification by Category", ylabel="Percentage")
plt.tight_layout()
plt.savefig("category_distribution.png")
plt.show()

# Emerging trends (Top words by TF-IDF)
tfidf = TfidfVectorizer(stop_words='english', max_features=50)
X_tfidf = tfidf.fit_transform(df["story"])
keywords = tfidf.get_feature_names_out()
sums = X_tfidf.sum(axis=0)
keyword_scores = [(word, sums[0, idx]) for idx, word in enumerate(keywords)]
emerging_trends = sorted(keyword_scores, key=lambda x: x[1], reverse=True)[:10]

print("\n Top Emerging Trends:")
for word, score in emerging_trends:
    print(f"{word}: {round(score, 2)}")

# Conclusions
print("\n Conclusions:")
print(f"- {len(stories)} stories processed.")
print(f"- {len(set(topics)) - 1} unique topics identified.")
print(f"- Most common entity types: {entity_counts.most_common(3)}")
print(f"- Emerging trends include: {[t[0] for t in emerging_trends]}")
print(f"- Top category by classification: {category_distribution.idxmax()}")
